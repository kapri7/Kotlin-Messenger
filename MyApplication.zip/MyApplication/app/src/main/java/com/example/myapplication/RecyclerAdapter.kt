package com.example.myapplication

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.myapplication.Contact
import com.example.myapplication.R
import kotlinx.android.synthetic.main.contact_data.view.*
import java.util.ArrayList

class RecyclerAdapter(val context: Context, val list: ArrayList<Contact>):RecyclerView.Adapter<RecyclerAdapter.ViewHolder>() {

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(context).inflate(R.layout.contact_data, parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.ivContactPhoto.setImageBitmap(list[position].photo)
        holder.tvEmail.text = list[position].email
        holder.tvPhoneNumber.text = list[position].phoneNumber
        holder.tvContactName.text = list[position].name
    }




    class ViewHolder(view: View):RecyclerView.ViewHolder(view){
        val tvContactName = view.contact_name
        val tvPhoneNumber = view.contact_phone_number
        val tvEmail = view.contact_email
        val ivContactPhoto = view.contact_photo
    }
}