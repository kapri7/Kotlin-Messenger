package com.example.myapplication

import android.Manifest
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.net.sip.SipAudioCall
import android.net.sip.SipManager
import android.net.sip.SipProfile
import android.net.sip.SipRegistrationListener
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*

open class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupPermissions()
        button.setOnClickListener { buildSipProfile(0) }
    }

    private fun setupPermissions() {
        val permission = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.USE_SIP
        )
        val permission2 = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        )
        val permission3 = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.READ_CONTACTS
        )
        if (permission != PackageManager.PERMISSION_GRANTED
            || permission2 != PackageManager.PERMISSION_GRANTED
            || permission3 != PackageManager.PERMISSION_GRANTED) {
            val PERMISSIONS = 1
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.USE_SIP, Manifest.permission.RECORD_AUDIO,Manifest.permission.READ_CONTACTS),
                PERMISSIONS
            )
        }
    }

    val sipManager: SipManager? by lazy(LazyThreadSafetyMode.NONE) {
        SipManager.newInstance(this)
    }
    var sipProfile: SipProfile? = null

    protected fun updateStatus(string: String) {
        Log.d("SIP", string)
        //        Toast.makeText(this@MainActivity, string, Toast.LENGTH_SHORT)
        // .show()
    }

    protected fun buildSipProfile(a: Int) { //a ==0 - after all we start basic activity because we are on registration step else just register profile
        //val username: String = editUserName.text.toString()
        val username: String = "5955019"
        //val domain: String = editDomain.text.toString()
        val domain: String = "195.214.214.253"
        //val password: String = editPassword.text.toString()
        val password: String = "f7SnaRiL"
        val builder = SipProfile.Builder(username, domain)
            .setPassword(password)
        sipProfile = builder.build()
        //builder.setAutoRegistration(true)
        val intent = Intent("android.SipDemo.INCOMING_CALL")
        val pendingIntent: PendingIntent = PendingIntent.getBroadcast(this, 0, intent, Intent.FILL_IN_DATA)
        try {
            sipManager?.open(sipProfile, pendingIntent, null)

        } catch (ee: Exception) {
            updateStatus("Failed to open local profile.")
        }
        updateStatus(sipProfile!!.uriString)
        sipManager?.setRegistrationListener(sipProfile?.uriString, object : SipRegistrationListener {

            override fun onRegistering(localProfileUri: String) {
                updateStatus("Registering with SIP Server...")
            }

            override fun onRegistrationDone(localProfileUri: String, expiryTime: Long) {
                updateStatus("Ready")
                if (a == 0) {
                    startActivity(Intent(this@MainActivity, NavigationActivity::class.java))
                    finish()
                }
            }

            override fun onRegistrationFailed(
                localProfileUri: String,
                errorCode: Int,
                errorMessage: String
            ) {
                updateStatus("Registration failed. Please check settings.")
            }
        })
    }

    protected fun audio() {
        var listener: SipAudioCall.Listener = object : SipAudioCall.Listener() {

            override fun onCallEstablished(call: SipAudioCall) {
                updateStatus("call established")
                call.apply {
                    startAudio()
                    setSpeakerMode(true)
                    toggleMute()
                }
            }

            override fun onCallEnded(call: SipAudioCall) {
                // Do something.
                updateStatus("Call ended")
            }
        }
        try {
            val call: SipAudioCall? = sipManager?.makeAudioCall(
                sipProfile?.uriString,
                "sip:600@195.214.214.253",
                listener,
                30
            )
            if (!call!!.isInCall) {
                updateStatus(call.toString())
            }
        } catch (ee: Exception) {
            updateStatus(ee.toString())
        }
    }

    fun closeLocalProfile() {
        try {
            sipManager?.close(sipProfile?.uriString)
            updateStatus("Closing...")
        } catch (ee: Exception) {
            updateStatus("Failed to close local profile.")
        }
    }

    override fun onDestroy() {
        //  closeLocalProfile()
        super.onDestroy()
    }
}
